[N, delta] = readvars("trapezio.dat");
figure;
hold on;
grid on;

plot(N,delta);

[N, delta] = readvars("simpson.dat");
plot(N,delta);

[N, delta] = readvars("romberg3.dat");
plot(N,delta);

[N, delta] = readvars("romberg4.dat");
plot(N,delta);

set(0,'defaultTextInterpreter','latex');
xlabel('$j$');
ylabel('$\Delta$');
legend('Trapezio','Simpson','Romberg3','Romberg4','Location','Southeast');
hold off;

path="confronto_100.png";
print(gcf,path,'-dpng','-r600');