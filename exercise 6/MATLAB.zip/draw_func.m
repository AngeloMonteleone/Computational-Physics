func = @(x) ((abs(x)+3)^5)*exp(-6-9*abs(x));
%fplot(func);
%legend("H(x)");
%xlabel("x")
%ylabel("")
plot_func("x","","H(x)",true,func,[-2 2 0 .7]);