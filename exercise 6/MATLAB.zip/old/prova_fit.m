% myfit('trapezio.dat', [0.5,0.5,.2,.2], 'Modello', 'Southeast','$N$','$\Delta$','red',[1 200],false,[2,0.01,.1],0,"fit_trapezio.png")
myfit('simpson.dat', [0.5,0.5,.2,.2], 'Modello', 'Southeast','$N$','$\Delta$','red',[3 100],false,[4,0.0001,-.001],0,"fit_simpson.png")
%il fit converge solo se si parte dal nono punto in poi con SIMPSON