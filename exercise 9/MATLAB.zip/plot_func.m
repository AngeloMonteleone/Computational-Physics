function [] = plot_func(xlab,ylab,leg,grid_on,func,lims)
    fplot(func);
    axis(lims)
    legend(leg);
    xlabel(xlab);
    ylabel(ylab);
    if(grid_on)
       grid on;
    end
end