[asc,ord] = readvars('coef_unif6.dat');

figure;
hold on;
scatter(asc,ord,'*');

[asc,ord] = readvars('coef_coin6.dat');

scatter(asc,ord,'*');

set(0,'defaultTextInterpreter','latex');
xlabel('$N$');
ylabel('$\langle x^6 \rangle / \langle x^2 \rangle^3$');
yline(15,'-','y=15','Color','red','LineWidth',1.5);

legend('Uniforme','Moneta','Location','Northwest');
hold off;