[asc,ord] = readvars('coef_unif6.dat');

% sz=size(ord);
% str="media valori uniforme: ";
% val = sum(ord)/(sz(1));
% str= str + val + newline + "media valori moneta: ";
% display(sum(ord)/(sz(1)))

figure;
hold on;
scatter(asc,ord,'*');


[asc,ord] = readvars('coef_coin6.dat');

% sz=size(ord);
% val = sum(ord)/(sz(1));
% str= str + val;
% display(sum(ord)/(sz(1)))

scatter(asc,ord,'*');

set(0,'defaultTextInterpreter','latex');
xlabel('$N$');
ylabel('$\langle x^6 \rangle / \langle x^2 \rangle^3$');
yline(15,'-','y=15','Color','red','LineWidth',1.5);
% dim=[.4 .7 .2 .2];
% annotation('textbox',dim,'String',str,'FitBoxToText','on','Color','red');
legend('Uniforme','Moneta','Location','Northwest');
hold off;