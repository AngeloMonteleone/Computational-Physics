[a]=readvars("unif.dat");
figure;
h=histogram(a,25);
% counts = h.Values;
% sumcounts = sum(counts);
% display(counts/sumcounts);
% counts = counts/sumcounts;
% h.Values = counts;
set(0,'defaultTextInterpreter','latex');
xlabel("$N$")
ylabel("Conteggi")