% [a,b]=readvars('mom_unif6.dat');
% display(a);
% display(b);
% ft = fittype('a+x*c',...
%     'dependent',{'y'},'independent',{'x'},...
%     'coefficients',{'a','c'});
% fit_given_cols(a,b,[.2 .2 .7 .3],"Modello","Northwest","$N$","$\langle x^6 \rangle$","red",[5 90],true,[ .1 3.1],ft)
% 
% [a,b]=readvars('mom_unif4.dat');
% display(a);
% display(b);
% ft = fittype('a+x*c',...
%     'dependent',{'y'},'independent',{'x'},...
%     'coefficients',{'a','c'});
% fit_given_cols(a,b,[.2 .2 .7 .3],"Modello","Northwest","$N$","$\langle x^4 \rangle$","red",[1 90],true,[.1 2.1],ft)
% 
[a,b]=readvars('mom_unif2.dat');
display(a);
display(b);
ft = fittype('a+x*c',...
    'dependent',{'y'},'independent',{'x'},...
    'coefficients',{'a','c'});
fit_given_cols(a,b,[.2 .2 .7 .3],"Modello","Northwest","$N$","$\langle x^2 \rangle$","red",[1 90],true,[.1 1.1],ft)