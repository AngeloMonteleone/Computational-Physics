[a]=readvars("cdf1.dat");
figure;
hold on;
h=histogram(a,100,'Normalization','pdf');
set(0,'defaultTextInterpreter','latex');
xlabel("$x$")
ylabel("Conteggi")
func = @(x) exp(-x+2)/(exp(2)-1);
plot_func('x','',true,func,[0 2 0 1.2]);
legend("Dati funzione inversa","f(x)");
hold off;

path="cdf1.png";
print(gcf,path,'-dpng','-r600');