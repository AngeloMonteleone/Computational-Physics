set(0,'defaultTextInterpreter','latex');
syms x
f=@(x) (x*cos(x))
g=@(x) (x*sin(x));
figure;
hold on;
fplot(f,[0 pi/2.]);
fplot(g,[0 pi]);
hold off;
legend('$f_1(x)$','$f_2(x)$','Location','northeast');
xlabel('x');