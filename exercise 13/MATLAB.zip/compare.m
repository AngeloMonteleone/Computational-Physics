%confronto tra i dati per Monte Carlo e importance sampling. I file per
%Monte carlo hanno la sigla "mc", mentre quelli per l'importance sampling
%hanno la sigla "is"
set(0,'defaultTextInterpreter','latex');
[N,data]=readvars('is1.dat');
figure;
xlabel("$N$");
ylabel("$err(I)$");
hold on;
scatter(N,data,'*');
[N,data]=readvars('mc1.dat');
scatter(N,data,'*');
legend("Importance sampling","Monte Carlo sampling","Location","northeast");
hold off;