figure;
hold on;
[asc,ord,times] = readvars('trapezio.dat');
scatter(arrayfun(@(x) 1/x,asc),times,'*');
[asc,ord,times] = readvars('simpson.dat');
scatter(arrayfun(@(x) 1/x,asc),times,'*');
set(0,'defaultTextInterpreter','latex');
xlabel('$N$');
ylabel('Tempo di calcolo');
legend('Trapezio','Simpson','Location','Northwest');
hold off;

path="tempi.png";
print(gcf,path,'-dpng','-r600');