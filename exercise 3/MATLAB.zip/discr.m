[asc,ord] = readvars('trapezio.dat');
figure;
hold on;
grid on;
scatter(asc,ord,'*');
[asc,ord] = readvars('simpson.dat');
scatter(asc,ord,'*');
set(0,'defaultTextInterpreter','latex');
xlabel('$\frac{1}{N}$');
ylabel('$\Delta$');
xlim([0.01 0.05]);
legend('Trapezio','Simpson','Location','Northwest');
hold off;

path="discr_zoom.png";
print(gcf,path,'-dpng','-r600');