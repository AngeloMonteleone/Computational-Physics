%Dati realtivi all'esecuzione:  ./esercizio2.exe 200 epsilon_longdouble.dat 2 1 0
%                               ./esercizio2.exe 200 epsilon_double.dat 1 1 0    
%                               ./esercizio2.exe 200 epsilon_float.dat 0 1 0 
[n,del] = readvars("epsilon_float.dat");
figure;
hold on;
grid on;
set(0,'defaultTextInterpreter','latex');
xlabel("$n$");
ylabel("$log(\Delta_n)$")
plot(n,log(del),"LineWidth",1.5);
[n,del] = readvars("epsilon_double.dat");
plot(n,log(del),"LineWidth",1.5);
[n,del] = readvars("epsilon_longdouble.dat");
plot(n,log(del),"LineWidth",1.5);
legend("Precisione singola","Precisione doppia","Precisione estesa","Location","northwest");

path="epsilon.png";
print(gcf,path,'-dpng','-r600');