%Dati realtivi all'esecuzione:  ./esercizio2.exe 200 float.dat 0 0 0
%                               ./esercizio2.exe 200 falsefloat.dat 2 0 1
[n,del] = readvars("float.dat");
data1=[n,log(del)];
[n,del] = readvars("falsefloat.dat");
data2=[n,log(del)];

zoomplot(["$n$", "$log(\Delta_n)$"],[[0 200];[-20 80]],data1,data2, ...
    [1 2], [98 102], [.69 .18 .2 .15], [.5 .5 .02 .03],[0 0],[1 1], ...
    ["Precisione singola", "Precisione singola simulata","northwest"],1,'false.png');
