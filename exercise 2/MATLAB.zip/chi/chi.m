%Dati realtivi all'esecuzione:  ./esercizio2.exe 200 chi_float.dat 0 0 0
%                               ./esercizio2.exe 200 chi_double.dat 1 0 0
%                               ./esercizio2.exe 200 chi_longdouble.dat 2 0 0
[n,del] = readvars("chi_float.dat");
figure;
hold on;
grid on;
set(0,'defaultTextInterpreter','latex');
xlabel("$n$");
ylabel("$log(\Delta_n)$")
plot(n,log(del),"LineWidth",1.5);
[n,del] = readvars("chi_double.dat");
plot(n,log(del),"LineWidth",1.5);
[n,del] = readvars("chi_longdouble.dat");
plot(n,log(del),"LineWidth",1.5);
legend("Precisione singola","Precisione doppia","Precisione estesa","Location","northwest");

path="chi.png";
print(gcf,path,'-dpng','-r600');