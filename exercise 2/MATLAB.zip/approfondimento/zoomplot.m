function [] = zoomplot(labels,limits,data1,data2,data3,colsToPlot,zoomRange, ...
    greatRectDim,smallRectDim,leftLine,rightLine,leg,save,path)

    figure;
    hold on;
    set(0,'defaultTextInterpreter','latex');
    %ETICHETTE ASSI
    xlabel(labels(1));
    ylabel(labels(2));
    
    %LIMITI ASSI
    xlim(limits(1,:));
    ylim(limits(2,:));
    
    %PLOT PRINCIPALE
    plot(data1(:,colsToPlot(1)),data1(:,colsToPlot(2)),"LineWidth",1.5)
    plot(data2(:,colsToPlot(1)),data2(:,colsToPlot(2)),"LineWidth",1.5)
    plot(data3(:,colsToPlot(1)),data3(:,colsToPlot(2)),"LineWidth",1.5)

    grid on;
    legend(leg(1), leg(2), leg(3),"Location",leg(4));
    
    %COORDINATE E DIMENSIONI DEL RETTANGOLO PRINCIPALE
    xpos = greatRectDim(1);
    ypos = greatRectDim(2);
    xwid = greatRectDim(3);
    ywid = greatRectDim(4);
    
    sub = axes("Position",greatRectDim);

    ran=zoomRange;%RANGE DI VALORI DELLA VARIABILE INDIPENDENTE DA USARE PER ZOOMARE
    index = data1(:,1)>ran(1) & data1(:,1)<ran(2);%SI USANO I VALORI RELATIVI ALLA PRIMA COLONNA PER SCEGLIERE LA ZONA DELLO ZOOM ANCHE SE SI PLOTTANO LE ALTRE DUE
    
    %ASCISSE E ORDINATE PER IL PRIMO SET DI DATI
    asc1 = data1(:,colsToPlot(1));
    ord1 = data1(:,colsToPlot(2));
    
    %ASCISSE E ORDINATE PER IL SECONDO SET DI DATI
    asc2 = data2(:,colsToPlot(1));
    ord2 = data2(:,colsToPlot(2));
    
    %ASCISSE E ORDINATE PER IL TERZO SET DI DATI
    asc3 = data3(:,colsToPlot(1));
    ord3 = data3(:,colsToPlot(2));
    

    %ASCISSE E ORDINATE PER IL PRIMO SET DI DATI
    plot(asc1(index),ord1(index),asc2(index),ord2(index),asc3(index),ord3(index));
    
    %LIMITI ORDINATE PER IL PLOT SECONDARIO, SI PRENDE IL PRIMO E ULTIMO VALORE
    %NELLA COLONNA DI DATI CHE VIENE PLOTTATA COME ESTREMI DA USARE PER GLI
    %ASSI
    vals=ord2(index);
    sz=size(vals);
    if(vals(1)<vals(sz(1)))
        sub.YLim=[vals(1) vals(sz(1))];
    else
        sub.YLim=[vals(sz(1)) vals(1)];
    end

    %LIMITI ASCISSE PER IL PLOT SECONDARIO, SI PRENDE IL PRIMO E ULTIMO VALORE
    %NELLA COLONNA DI DATI CHE VIENE PLOTTATA COME ESTREMI DA USARE PER GLI
    %ASSI
    vals=asc2(index);
    sz=size(vals);
    if(vals(1)<vals(sz(1)))
        sub.XLim=[vals(1) vals(sz(1))];
    else
        sub.XLim=[vals(sz(1)) vals(1)];
    end
    
    %COORDINATE E DIMENSIONI DEL RETTANGOLO PICCOLO
    small_rect_x = smallRectDim(1);
    small_rect_y = smallRectDim(2);
    small_rect_xwid = smallRectDim(3);
    small_rect_ywid = smallRectDim(4);
    
    %COORDINATE FRECCIA DESTRA
    %rightLine è un vettore di due valori che possono essere zero o uno:
    %1 corrisponde all'angolo "alto" del rettangolo
    %0 corrisponde all'angolo "basso" del rettangolo
    x1 =  [small_rect_x+small_rect_xwid xpos+xwid];
    y1 = [small_rect_y+small_rect_ywid*rightLine(1) ypos+ywid*rightLine(2)];
    
    annotation("line",x1,y1,"Color","#767676");
    
    %COORDINATE FRECCIA SINISTRA
    %leftLine è un vettore di due valori che possono essere zero o uno:
    %1 corrisponde all'angolo "alto" del rettangolo
    %0 corrisponde all'angolo "basso" del rettangolo
    x1 =  [small_rect_x xpos];
    y1 = [small_rect_y+small_rect_ywid*leftLine(1) ypos+ywid*leftLine(2)];
    
    annotation("line",x1,y1,"Color","#767676");
    
    annotation("rectangle",smallRectDim,"Color","#767676");
    
    %SALVATAGGIO IMMAGINE
    if(save)
        print(gcf,path,'-dpng','-r600');
    end
end