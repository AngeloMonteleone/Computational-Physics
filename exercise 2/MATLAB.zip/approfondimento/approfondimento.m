%Dati realtivi all'esecuzione:  ./esercizio2.exe 180 approfondimento_float.dat 0 0 0
%                               ./esercizio2.exe 180 approfondimento_double.dat 1 0 0
%                               ./esercizio2.exe 180 approfondimento_longdouble.dat 2 0 0  
[n,del] = readvars("approfondimento_float.dat");
data1=[n,log(del)];
[n,del] = readvars("approfondimento_double.dat");
data2=[n,log(del)];
[n,del] = readvars("approfondimento_longdouble.dat");
data3=[n,log(del)];

zoomplot(["$n$", "$log(\Delta_n)$"],[[0 180];[0 90]],data1,data2,data3, ...
    [1 2], [98 102], [.69 .18 .2 .15], [.52 .5 .02 .03],[0 0],[1 1], ...
["Precisione singola", "Precisione doppia","Precisione estesa","northwest"],1,'approfondimento.png');
