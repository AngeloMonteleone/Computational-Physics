
%Dati relativi all'input: "./es18new.exe .001 20000"

[t,E] = readvars("set1/ener_eulero.dat");
data1=[t,E];
[t,E] = readvars("set1/ener_rk2.dat");
data2=[t,E];
[t,E] = readvars("set1/ener_rk4.dat");
data3=[t,E];

zoomplot(["$t$", "$E$"],[[0 20];[-.3 .3]],[[9.9 10];[-0.2116 -0.2106]],data1,data2,data3, ...
    [1 2], [9.9 10], [.7 .75 .2 .15], [.5 .23 .02 .02],[1 1],[0 0], ...
    ["Eulero", "RK2","RK4","northwest"],1,'images/set1_ener.png');