
%Dati relativi all'input: "./es18new.exe .001 20000"
[t,E] = readvars("set1/ener_eulero.dat");
figure;
hold on;

plot(t,E,"LineWidth",1.5);

[t,E] = readvars("set1/ener_rk2.dat");
plot(t,E,"LineWidth",1.5);

[t,E] = readvars("set1/ener_rk4.dat");
plot(t,E,"LineWidth",1.5);

ylim([-4 1])
grid on;

set(0,'defaultTextInterpreter','latex');
xlabel('$t$');
ylabel('$E$');
legend('Eulero','RK2','RK4','Location','Northwest');
hold off;

path="images/set1_ener.png";
print(gcf,path,'-dpng','-r600');

hold off;