
%Dati relativi all'input: "./es18new.exe .001 25000"
[t,x0,y0,z0,x1,y1,z1,x2,y2,z2] = readvars("set2/rk2.dat");
figure;
hold on;

plot3(x0,y0,z0,"LineWidth",1.5);
plot3(x1,y1,z1,"LineWidth",1.5);
plot3(x2,y2,z2,"LineWidth",1.5);

grid on;
view(90,0);

set(0,'defaultTextInterpreter','latex');
xlabel('$x$');
ylabel('$y$');
zlabel('$z$');
legend('Corpo 1','Corpo 2','Corpo 3','Location','Northeast');
hold off;

path="images/set2_rk2_side.png";
print(gcf,path,'-dpng','-r600');

hold off;