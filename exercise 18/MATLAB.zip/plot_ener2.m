
%Dati relativi all'input: "./es18new.exe .001 25000"
[t,E] = readvars("set2/ener_eulero.dat");
figure;
hold on;

plot(t,E,"LineWidth",1.5);

[t,E] = readvars("set2/ener_rk2.dat");
plot(t,E,"LineWidth",1.5);

[t,E] = readvars("set2/ener_rk4.dat");
plot(t,E,"LineWidth",1.5);

grid on;

set(0,'defaultTextInterpreter','latex');
xlabel('$t$');
ylabel('$E$');
legend('Eulero','RK2','RK4','Location','Southwest');
hold off;

path="images/set2_ener.png";
print(gcf,path,'-dpng','-r600');

hold off;