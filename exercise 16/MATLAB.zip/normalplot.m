function [] = normalplot(labels,limits,data1,data2,data3,colsToPlot,leg,save,path)

    figure;
    hold on;
    set(0,'defaultTextInterpreter','latex');
    %ETICHETTE ASSI
    xlabel(labels(1));
    ylabel(labels(2));
    
    %LIMITI ASSI
    xlim(limits(1,:));
    ylim(limits(2,:));
    
    %PLOT PRINCIPALE
    plot(data1(:,colsToPlot(1)),data1(:,colsToPlot(2)),"LineWidth",1.5)
    plot(data2(:,colsToPlot(1)),data2(:,colsToPlot(2)),"LineWidth",1.5)
    plot(data3(:,colsToPlot(1)),data3(:,colsToPlot(2)),"LineWidth",1.5)

    grid on;
    legend(leg(1), leg(2), leg(3),"Location",leg(4));
    
    %SALVATAGGIO IMMAGINE
    if(save)
        print(gcf,path,'-dpng','-r600');
    end
end