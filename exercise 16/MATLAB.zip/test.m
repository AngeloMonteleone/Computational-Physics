[t1,angle1,speed1] = readvars("set3/eulero.dat");
data1=[t1,angle1,speed1];