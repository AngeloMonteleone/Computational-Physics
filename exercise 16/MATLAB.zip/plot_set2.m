%Dati relativi all'input: "./esercizio16.exe .05 1000 .5 .63 .03" 

[t1,angle1,speed1] = readvars("set2/eulero.dat");
data1=[t1,angle1,speed1];
% plot(t1,angle1,"LineWidth",1.5);

[t2,angle2,speed2] = readvars("set2/rk2.dat");
data2=[t2,angle2,speed2];
% plot(t2,angle2,"LineWidth",1.5);

[t3,angle3,speed3] = readvars("set2/rk4.dat");
data3=[t3,angle3,speed3];
% plot(t3,angle3,"LineWidth",1.5);

% [data1,data2,data3]

%INPUT PLOT FASI
% normalplot(["$\theta$", "$\theta'(\theta)$"],[[10 30];[-10 10]],data1,data2,data3, ...
%     [2 3],["Eulero", "RK2","RK4","northwest"],1,'images/set2_fasi_bis.png');

% INPUT PLOT VELOCITA'
% normalplot(["$t$", "$\theta'(t)$"],[[0 50];[-2.5 10]],data1,data2,data3, ...
%     [1 3],["Eulero", "RK2","RK4","northwest"],1,'images/set2_vel.png');

%INPUT PLOT ANGOLO
% normalplot(["$t$", "$\theta(t)$"],[[0 50];[-2.5 10]],data1,data2,data3, ...
%     [1 2],["Eulero", "RK2","RK4","northwest"],1,'images/set2_angolo.png');