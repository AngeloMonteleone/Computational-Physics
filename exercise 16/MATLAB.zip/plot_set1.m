%Dati relativi all'input: "./esercizio16.exe .05 1000 .5 .5 .03" 

[t1,angle1,speed1] = readvars("set1/eulero.dat");
data1=[t1,angle1,speed1];
% plot(t1,angle1,"LineWidth",1.5);

[t2,angle2,speed2] = readvars("set1/rk2.dat");
data2=[t2,angle2,speed2];
% plot(t2,angle2,"LineWidth",1.5);

[t3,angle3,speed3] = readvars("set1/rk4.dat");
data3=[t3,angle3,speed3];
% plot(t3,angle3,"LineWidth",1.5);

% [data1,data2,data3]

%INPUT PLOT FASI
% zoomplot(["$\theta$", "$\theta'(\theta)$"],[[-.5 .5];[-.5 .5]],data1,data2,data3, ...
%     [2 3], [40.7 40.9], [.7 .75 .2 .15], [.5 .65 .02 .03],[1 1],[0 0], ...
%     ["Eulero", "RK2","RK4","northwest"],1,'images/set1_fasi.png');

% INPUT PLOT VELOCITA'
% zoomplot(["$t$", "$\theta'(t)$"],[[0 50];[-1 1]],data1,data2,data3, ...
%     [1 3], [45.5 45.7], [.7 .75 .2 .15], [.825 .5 .015 .02],[0 0],[0 0], ...
%     ["Eulero", "RK2","RK4","northwest"],1,'images/set1_vel.png');

%INPUT PLOT ANGOLO
% zoomplot(["$t$", "$\theta(t)$"],[[0 50];[-1 1]],data1,data2,data3, ...
%     [1 2], [40.7 40.9], [.7 .75 .2 .15], [.745 .45 .015 .02],[0 0],[0 0], ...
%     ["Eulero", "RK2","RK4","northwest"],1,'images/set1_angolo.png');