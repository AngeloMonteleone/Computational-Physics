%lettura dati (si può cambiare il nome del file a seconda di cosa si vuole
%plottare)
[asc,ord]=readvars("int5hm.dat");
set(0,'defaultTextInterpreter','latex');
sz = size(asc);
for k=1:sz(1)
    asc(k)=1/asc(k);
end
figure;
hold on;
scatter(asc,ord,"*");

%lettura dati (si può cambiare il nome del file a seconda di cosa si vuole
%plottare)
[asc,ord]=readvars("int5mc.dat");
sz = size(asc);
for k=1:sz(1)
    asc(k)=1/asc(k);
end
scatter(asc,ord,"*");

xlabel('$N$');
ylabel('$err(I)$');
legend('Dati hit or miss','Dati Monte Carlo','Location','Northeast');
hold off;
