%lettura dati (si può cambiare il nome del file a seconda di cosa si vuole
%fittare)
[asc,ord] = readvars('int5hm.dat');
set(0,'defaultTextInterpreter','latex');

legend('Dati','Location','Northeast');
ft = fittype('a+b*(x)',...
    'dependent',{'y'},'independent',{'x'},...
    'coefficients',{'a','b'});
fit_given_cols(asc,ord,[.2 .2 .7 .3],"Modello","Northwest","$log(1/N)$","$log(err(I))$","red",[1 100],true,[.1 .5],ft)
