figure;
hold on;
set(0,'defaultTextInterpreter','latex');
xlabel("$t$");
ylabel("$\theta(t)$");
ylim([-3 3])

[t1,angle1,speed1] = readvars("semplice/eulero.dat");
plot(t1,angle1,"LineWidth",1.5);

[t2,angle2,speed2] = readvars("semplice/rk2.dat");
plot(t2,angle2,"LineWidth",1.5);

[t3,angle3,speed3] = readvars("semplice/rk4.dat");
plot(t3,angle3,"LineWidth",1.5);

legend("Eulero", "RK2", "RK4","Location","northwest");

sub = axes("Position",[.6 .16 .2 .15]);
index = t1>10.3 & t1<10.4;
plot(t1(index),angle1(index),t2(index),angle2(index),t3(index),angle3(index)); 