tab = readtable("data.dat");
tab = table2array(tab);
I = mat2gray(tab);
image(I,"CDataMapping","scaled");
colorbar
colormap turbo;
path="fractal100.png";
print(gcf,path,'-dpng','-r600');