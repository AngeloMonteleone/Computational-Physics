
%Dati realtivi all'input: ./esercizio17.exe .01 5000 1 1 1
[t,x,y,z]= readvars('noise/eulero.dat');

figure;
hold on;
plot3(x,y,z,"LineWidth",1);
grid on;
view(40,35);

[t,x,y,z]= readvars('noise/rk2.dat');
plot3(x,y,z,"LineWidth",1);
[t,x,y,z]= readvars('noise/rk4.dat');
plot3(x,y,z,"LineWidth",1);

xs = 6*sqrt(2);
ys = 6*sqrt(2);
zs = 27;
scatter3(xs,ys,zs,15,"filled","MarkerFaceColor","Black");
scatter3(-xs,-ys,zs,15,"filled","MarkerFaceColor","Black");

set(0,'defaultTextInterpreter','latex');
xlabel('$x$');
ylabel('$y$');
zlabel('$z$');
legend('Eulero','RK2','RK4','Location','Northwest');
hold off;

path="images/plot3d_equilibrium.png";
print(gcf,path,'-dpng','-r600');