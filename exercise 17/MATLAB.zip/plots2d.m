[t,x,y,z]= readvars('eulero.dat');
figure;
tiledlayout(2,2);

p1=nexttile;
plot(x,y);
grid(p1,"on");

p2=nexttile;
plot(x,z);
grid(p2,"on");

p3=nexttile;
plot(y,z);
grid(p3,"on");

p4=nexttile;
plot3(x,y,z,"LineWidth",1.5);
grid(p4,"on");
view(40,35);