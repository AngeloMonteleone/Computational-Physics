%lettura dei dati. In questo caso si leggono i dati per i numeri
%generati esattamente. Il file gaussAR.dat invece contiene i dati
%generati con metodo accept & reject.
%L'unico cambio da effettuare nel codice se si vogliono plottare 
%questi ultimi dati è la legenda
[a]=readvars("cdf.dat");
figure;
hold on;
h=histogram(a,100,'Normalization','pdf');
set(0,'defaultTextInterpreter','latex');
xlabel("$x$")
ylabel("Conteggi")
func = @(x) (exp(-x*x))/(sqrt(pi))
plot_func('x','',true,func,[-4 4 0 .7]);

legend("Dati funzione inversa","f(x)");
hold off;

path="histINV.png";
print(gcf,path,'-dpng','-r600');