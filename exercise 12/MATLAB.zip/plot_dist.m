set(0,'defaultTextInterpreter','latex');
syms x
f=piecewise(x>0 & x<1,2/3,x>1,2*x*exp(1-x^2)/3);
g=@(x) (2*exp(-x^2)/3.);%rivedi normalizzazione
figure;
hold on;
fplot(f);
fplot(g,[0 5]);
hold off;
legend('f(x)','gaussiana','Location','northeast');
xlabel('x');